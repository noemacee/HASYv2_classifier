import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from torch.utils.data import TensorDataset, DataLoader


class MLP(nn.Module):
    """
    An MLP network which does classification.

    It should not use any convolutional layers.
    """

    def __init__(self, input_size, n_classes):
        """
        Initialize the network.

        You can add arguments if you want, but WITH a default value, e.g.:
            __init__(self, input_size, n_classes, my_arg=32)

        Arguments:
            input_size (int): size of the input
            n_classes (int): number of classes to predict
        """
        super().__init__()
        ##
        ###
        # WRITE YOUR CODE HERE!
        ###
        ##

    def forward(self, x):
        """
        Predict the class of a batch of samples with the model.

        Arguments:
            x (tensor): input batch of shape (N, D)
        Returns:
            preds (tensor): logits of predictions of shape (N, C)
                Reminder: logits are value pre-softmax.
        """
        ##
        ###
        # WRITE YOUR CODE HERE!
        ###
        ##
        return preds


class CNN(nn.Module):
    """
    A CNN which does classification.

    It should use at least one convolutional layer.
    """

    # Added filters as argument to make it easier to change the number of filters
    # Added padding as argument to make it easier to change the padding
    # Added kernel_size : the size of the convolution kernel : maybe change to a list to have different kernel sizes
    # Added stride : the stride of the convolution : maybe change to a list to have different strides
    # Added max_pooling_kernel : the size of the max_pooling kernel : maybe change to a list to have different kernel sizes
    # Added max_pooling_number : the number of max_pooling layers
    # Added mlp_size : the size of the linear layers

    # Only need to fix the number of filters and the layers of the MLP

    def __init__(self, input_channels, n_classes, filters=[16, 32, 64], conv_kernel_size=3, max_pooling_kernel=3, max_pooling_number=3, linear_layers_size=[120, 20], image_width_height=32):
        """
        Initialize the network.

        You can add arguments if you want, but WITH a default value, e.g.:
            __init__(self, input_channels, n_classes, my_arg=32)

        Arguments:
            input_channels (int): number of channels in the input
            n_classes (int): number of classes to predict
        """
        super(CNN, self).__init__()

        self.input_channels = input_channels
        self.n_classes = n_classes
        self.filters = filters
        self.conv_kernel_size = conv_kernel_size
        self.max_pooling_kernel = max_pooling_kernel
        self.max_pooling_number = max_pooling_number
        self.linear_layers_size = linear_layers_size

        self.conv2d1 = nn.Conv2d(
            input_channels, filters[0], conv_kernel_size)
        self.conv2d2 = nn.Conv2d(
            filters[0], filters[1], conv_kernel_size)
        self.conv2d3 = nn.Conv2d(
            filters[1], filters[2], conv_kernel_size)

        # Dimension of image after the pooling layers
        dimension = math.ceil(image_width_height /
                              (max_pooling_kernel ** max_pooling_number))

        self.linear1 = nn.Linear(
            filters[2] * dimension * dimension, linear_layers_size[0])

        self.linear2 = nn.Linear(linear_layers_size[0], linear_layers_size[1])

    def forward(self, x, max_pooling_kernel=2):
        """
        Predict the class of a batch of samples with the model.

        Arguments:
            x (tensor): input batch of shape (N, Ch, H, W)
        Returns:
            preds (tensor): logits of predictions of shape (N, C)
                Reminder: logits are value pre-softmax.
        """
        x = F.relu(self.conv2d1(x))

        x = F.max_pool2d(x, max_pooling_kernel)

        x = F.relu(self.conv2d2(x))
        x = F.max_pool2d(x, max_pooling_kernel)
        x = F.relu(self.conv2d3(x))
        x = F.max_pool2d(x, max_pooling_kernel)
        x = x.flatten(-3)  # Flatten the tensor to have a 1D tensor
        x = F.relu(self.linear1(x))
        preds = self.linear2(x)

        return preds


class Trainer(object):
    """
    Trainer class for the deep networks.

    It will also serve as an interface between numpy and pytorch.
    """

    def __init__(self, model, lr, epochs, batch_size):
        """
        Initialize the trainer object for a given model.

        Arguments:
            model (nn.Module): the model to train
            lr (float): learning rate for the optimizer
            epochs (int): number of epochs of training
            batch_size (int): number of data points in each batch
        """
        self.lr = lr
        self.epochs = epochs
        self.model = model
        self.batch_size = batch_size

        self.criterion = nn.CrossEntropyLoss()
        # Creates a state-less Stochastic Gradient Descent. Which one could be the best ?
        self.optimizer = torch.optim.SGD(
            model.parameters(), lr=lr)  # WRITE YOUR CODE HERE

    def train_all(self, dataloader):
        """
        Fully train the model over the epochs. 

        In each epoch, it calls the functions "train_one_epoch". If you want to
        add something else at each epoch, you can do it here.

        Arguments:
            dataloader (DataLoader): dataloader for training data
        """
        for ep in range(self.epochs):
            self.train_one_epoch(dataloader)

            # WRITE YOUR CODE HERE if you want to do add else at each epoch

    def train_one_epoch(self, dataloader):
        """
        Train the model for ONE epoch.

        Should loop over the batches in the dataloader. (Recall the exercise session!)
        Don't forget to set your model to training mode, i.e., self.model.train()!

        Arguments:
            dataloader (DataLoader): dataloader for training data
        """
        ##
        ###
        # WRITE YOUR CODE HERE!
        ###
        ##

        self.model.train()  # set model to training mode
        for it, batch in enumerate(dataloader):
            # Fet the inputs and labels
            inputs, labels = batch

            # Run the forward pass
            logits = self.model.forward(inputs)

            # Compute the loss
            loss = self.criterion(logits, labels)

            # Compute the gradients
            loss.backward()

            # Update the weights
            self.optimizer.step()

            # Reset the gradients
            self.optimizer.zero_grad()

    def predict_torch(self, dataloader):
        """
        Predict the validation/test dataloader labels using the model.

        Hints:
            1. Don't forget to set your model to eval mode, i.e., self.model.eval()!
            2. You can use torch.no_grad() to turn off gradient computation, 
            which can save memory and speed up computation. Simply write:
                with torch.no_grad():
                    # Write your code here.

        Arguments:
            dataloader (DataLoader): dataloader for validation/test data
        Returns:
            pred_labels (torch.tensor): predicted labels of shape (N,),
                with N the number of data points in the validation/test data.
        """
        ##
        ###
        # WRITE YOUR CODE HERE!
        ###
        ##
        self.model.eval()  # set model to evaluation mode
        pred_labels = torch.tensor([]).long()
        with torch.no_grad():
            for it, batch in enumerate(dataloader):
                x = batch[0]
                pred = self.model(x)
                pred_labels = torch.cat((pred_labels, pred))
        pred_labels = torch.argmax(pred_labels, axis=1)

        return pred_labels

    def fit(self, training_data, training_labels):
        """
        Trains the model, returns predicted labels for training data.

        This serves as an interface between numpy and pytorch.

        Arguments:
            training_data (array): training data of shape (N,D)
            training_labels (array): regression target of shape (N,)
        Returns:
            pred_labels (array): target of shape (N,)
        """
        # First, prepare data for pytorch
        train_dataset = TensorDataset(torch.from_numpy(training_data).float(),
                                      torch.from_numpy(training_labels))
        train_dataloader = DataLoader(
            train_dataset, batch_size=self.batch_size, shuffle=True)

        self.train_all(train_dataloader)

        return self.predict(training_data)

    def predict(self, test_data):
        """
        Runs prediction on the test data.

        This serves as an interface between numpy and pytorch.

        Arguments:
            test_data (array): test data of shape (N,D)
        Returns:
            pred_labels (array): labels of shape (N,)
        """
        # First, prepare data for pytorch
        test_dataset = TensorDataset(torch.from_numpy(test_data).float())
        test_dataloader = DataLoader(
            test_dataset, batch_size=self.batch_size, shuffle=False)

        pred_labels = self.predict_torch(test_dataloader)

        # We return the labels after transforming them into numpy array.
        return pred_labels.numpy()
